import { RefObject, useEffect } from 'react';

/** Adds `.is-paused` to the element while it is off-screen so decorative loops cost nothing. */
export const usePauseOffscreen = (ref: RefObject<Element | null>) => {
  useEffect(() => {
    const el = ref.current;
    if (!el || typeof IntersectionObserver === 'undefined') return;
    const io = new IntersectionObserver(([e]) => el.classList.toggle('is-paused', !e.isIntersecting));
    io.observe(el);
    return () => io.disconnect();
  }, [ref]);
};
