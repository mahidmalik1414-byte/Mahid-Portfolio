import { useEffect } from 'react';

/**
 * useScrollReveal
 * Adds '.is-revealed' to every '.reveal-on-scroll' element as it enters the viewport.
 * One IntersectionObserver for the whole app; a MutationObserver picks up elements that
 * mount later (route changes, lazy-loaded pages) and each element is released after it
 * has been revealed once. Respects 'prefers-reduced-motion'.
 */
export const useScrollReveal = () => {
  useEffect(() => {
    const root = document.getElementById('root');
    if (!root) return;

    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const seen = new WeakSet<Element>();

    const io = reduceMotion
      ? null
      : new IntersectionObserver(
          (entries) => {
            for (const entry of entries) {
              if (!entry.isIntersecting) continue;
              entry.target.classList.add('is-revealed');
              io!.unobserve(entry.target);
            }
          },
          { threshold: 0.1, rootMargin: '0px 0px -50px 0px' }
        );

    const scan = () => {
      root.querySelectorAll('.reveal-on-scroll').forEach((el) => {
        if (seen.has(el)) return;
        seen.add(el);
        if (io) io.observe(el);
        else el.classList.add('is-revealed');
      });
    };

    let frame = 0;
    const mo = new MutationObserver(() => {
      if (!frame) frame = requestAnimationFrame(() => { frame = 0; scan(); });
    });
    mo.observe(root, { childList: true, subtree: true });
    scan();

    return () => {
      mo.disconnect();
      io?.disconnect();
      if (frame) cancelAnimationFrame(frame);
    };
  }, []);
};
