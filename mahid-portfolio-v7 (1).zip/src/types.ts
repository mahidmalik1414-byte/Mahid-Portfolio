export interface Project {
  id: string;
  title: string;
  category: string;
  description: string;
  tools: string[];
  image: string;
  /** Real demo URL. Leave undefined until one exists: the card then shows "Demo coming soon". */
  url?: string;
  /** Renders the recorded-audio player instead of a link. */
  audioDemo?: boolean;
}

export interface Service {
  number: string;
  title: string;
  description: string;
  icon: 'bot' | 'phone' | 'layout' | 'globe' | 'search' | 'trending';
  tags?: string[];
}

export interface Tool {
  name: string;
  badge: string;
}
