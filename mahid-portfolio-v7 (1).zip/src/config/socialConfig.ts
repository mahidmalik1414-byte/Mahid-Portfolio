/**
 * Mahid Portfolio - Contact & Social Configuration
 * 
 * IMPORTANT:
 * - Real profiles provided are active (Instagram, GitHub).
 * - For fields marked as 'WAIT FOR REAL', leave as empty string or insert real values.
 * - When WHATSAPP_NUMBER is provided (e.g. '1234567890'), WhatsApp CTAs will open chat directly.
 * - When CONTACT_EMAIL is provided (e.g. 'mahid@example.com'), mailto links will activate.
 */

export const SOCIAL_CONFIG = {
  // Verified real links provided by Mahid
  INSTAGRAM_URL: 'https://www.instagram.com/mahid.dev',
  GITHUB_URL: 'https://github.com/mahidmalik1414-byte',

  // Pending real URLs from Mahid (do NOT invent fake URLs)
  FACEBOOK_URL: 'https://www.facebook.com/share/1DsExCeWKu/',
  LINKEDIN_URL: '', // Set when Mahid supplies LinkedIn profile URL

  // WhatsApp Configuration
  WHATSAPP_NUMBER: '923247364041',
  WHATSAPP_DIRECT_URL: 'https://wa.me/923247364041',
  WHATSAPP_PREFILLED_MESSAGE: "Hi Mahid, I found your portfolio and I'd like to discuss a project.",

  // Email Configuration (do NOT invent email)
  CONTACT_EMAIL: 'mahidmalikbusiness134@gmail.com',
  EMAIL_SUBJECT: 'Project Inquiry — Mahid.Malik',

  // Demo audio file path
  VOICE_AGENT_AUDIO_PATH: '/audio/voice-agent-demo.mp3',
};

/**
 * Returns formatted WhatsApp link
 */
export const getWhatsAppLink = (): string => {
  const cleanNumber = SOCIAL_CONFIG.WHATSAPP_NUMBER.replace(/[^0-9]/g, '') || '923247364041';
  const encodedMsg = encodeURIComponent(SOCIAL_CONFIG.WHATSAPP_PREFILLED_MESSAGE);
  return `https://wa.me/${cleanNumber}?text=${encodedMsg}`;
};

/**
 * Returns mailto link if email is present
 */
export const getEmailLink = (): string | null => {
  if (!SOCIAL_CONFIG.CONTACT_EMAIL.trim()) return null;
  return `mailto:${SOCIAL_CONFIG.CONTACT_EMAIL.trim()}?subject=${encodeURIComponent(SOCIAL_CONFIG.EMAIL_SUBJECT)}`;
};
