import imgSaas from '../assets/images/demo-saas.webp';
import imgDashboard from '../assets/images/demo-dashboard.webp';
import imgEcommerce from '../assets/images/demo-ecommerce.webp';
import { Project, Service, Tool } from '../types';

export const SERVICES: Service[] = [
  { number: '01', title: 'AI Automation', icon: 'bot', description: 'Automate repetitive workflows with intelligent AI systems.' },
  { number: '02', title: 'AI Voice Calling Agents', icon: 'phone', description: 'Build natural AI phone agents for real business workflows.' },
  { number: '03', title: 'SaaS Development', icon: 'layout', description: 'Turn product ideas into scalable SaaS experiences.' },
  { number: '04', title: 'Web Development', icon: 'globe', description: 'Fast, responsive websites built for real users.' },
  {
    number: '05', title: 'SEO', icon: 'search',
    description: 'Technical, on-page, local and off-page SEO systems.',
    tags: ['Technical', 'On-Page', 'Local', 'Off-Page'],
  },
  {
    number: '06', title: 'Digital Marketing', icon: 'trending',
    description: 'Performance-focused Google Ads, Meta Ads and social growth.',
    tags: ['Google Ads', 'Meta Ads', 'Social Media', 'Performance'],
  },
];

/**
 * Add a real `url` to a project and its card becomes a clickable external link.
 * Without a url the card is labelled "Demo coming soon".
 */
export const PROJECTS: Project[] = [
  {
    id: 'saas',
    title: 'Cognitive SaaS Platform',
    category: 'SaaS',
    description: 'AI-powered business dashboard with billing, analytics and team workspaces.',
    tools: ['React', 'TypeScript', 'Tailwind CSS'],
    image: imgSaas,
  },
  {
    id: 'voice-agent',
    title: 'AI Voice Agent',
    category: 'Voice AI',
    description: 'A voice agent that answers calls, qualifies leads and books appointments.',
    tools: ['Vapi', 'Retell AI', 'n8n'],
    image: '',
    audioDemo: true,
  },
  {
    id: 'store',
    title: 'Veloce Tech Store',
    category: 'E-commerce',
    description: 'A fast, minimal storefront with instant filtering and a smooth checkout flow.',
    tools: ['Next.js', 'TypeScript', 'Tailwind CSS'],
    image: imgEcommerce,
  },
  {
    id: 'marketing-dashboard',
    title: 'OmniScale Dashboard',
    category: 'Digital Marketing',
    description: 'One view for Google Ads and Meta Ads spend, conversions and ROAS.',
    tools: ['React', 'Google Ads', 'Meta Ads'],
    image: imgDashboard,
  },
];

export const TOOLS: Tool[] = [
  { name: 'JavaScript', badge: 'JS' },
  { name: 'TypeScript', badge: 'TS' },
  { name: 'React', badge: 'Re' },
  { name: 'Next.js', badge: 'Nx' },
  { name: 'Tailwind CSS', badge: 'TW' },
  { name: 'Node.js', badge: 'No' },
  { name: 'Python', badge: 'Py' },
  { name: 'FastAPI', badge: 'FA' },
  { name: 'PostgreSQL', badge: 'Pg' },
  { name: 'Supabase', badge: 'Sb' },
  { name: 'OpenAI', badge: 'AI' },
  { name: 'n8n', badge: 'n8n' },
  { name: 'Vapi', badge: 'Va' },
  { name: 'Retell AI', badge: 'Rt' },
  { name: 'Docker', badge: 'Dk' },
  { name: 'MCP', badge: 'MCP' },
  { name: 'RAG', badge: 'RAG' },
  { name: 'Git', badge: 'Git' },
  { name: 'GitHub', badge: 'GH' },
  { name: 'REST APIs', badge: 'API' },
  { name: 'Webhooks', badge: 'Hk' },
  { name: 'Google Ads', badge: 'Ads' },
  { name: 'Meta Ads', badge: 'Meta' },
  { name: 'Google Analytics', badge: 'GA' },
  { name: 'Search Console', badge: 'GSC' },
];

export const PROCESS = [
  { number: '01', title: 'Understand', description: 'Your goals, users and bottlenecks.' },
  { number: '02', title: 'Build', description: 'Fast, modern systems and integrations.' },
  { number: '03', title: 'Launch', description: 'Clean deployment, properly tested.' },
  { number: '04', title: 'Improve', description: 'Measure, learn and keep optimizing.' },
];

export const TRUST = [
  { title: 'Fast', description: 'Performance-first builds.' },
  { title: 'Practical', description: 'Built around real business needs.' },
  { title: 'Modern', description: 'Current AI workflows and frameworks.' },
  { title: 'Growth-focused', description: 'SEO and measurable marketing built in.' },
];
