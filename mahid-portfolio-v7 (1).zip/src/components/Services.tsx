import React from 'react';
import { Bot, PhoneCall, Layout, Globe, Search, TrendingUp, ArrowUpRight } from 'lucide-react';
import { SERVICES } from '../data/portfolioData';
import { SectionHeading } from './SectionHeading';

const ICONS = { bot: Bot, phone: PhoneCall, layout: Layout, globe: Globe, search: Search, trending: TrendingUp };

export const Services: React.FC = () => (
  <section id="services" aria-labelledby="services-title" className="scroll-mt-16 py-28 lg:py-40">
    <div className="mx-auto max-w-7xl px-5 sm:px-8 lg:px-12">
      <SectionHeading id="services-title" eyebrow="What I do" title="Core Services" />

      <ul className="mt-16 grid grid-cols-1 gap-px overflow-hidden rounded-3xl border border-white/[0.08] bg-white/[0.08] md:grid-cols-2 lg:grid-cols-3">
        {SERVICES.map((s, i) => {
          const Icon = ICONS[s.icon];
          return (
            <li key={s.number} className="reveal-on-scroll bg-[#07090E]" style={{ transitionDelay: `${(i % 3) * 80}ms` }}>
              <a
                href="#contact"
                className="group relative flex h-full min-h-[264px] flex-col p-8 transition-colors duration-300 hover:bg-[#0B0F19] sm:p-10"
                aria-label={`${s.title}: ${s.description} Get in touch`}
              >
                {/* Accent line grows in on hover (transform only) */}
                <span className="absolute inset-x-0 top-0 h-px origin-left scale-x-0 bg-gradient-to-r from-blue-400 to-cyan-300 transition-transform duration-500 group-hover:scale-x-100" />

                <div className="flex items-start justify-between">
                  <span className="font-mono text-sm text-slate-500 transition-colors duration-200 group-hover:text-blue-400">{s.number}</span>
                  <Icon className="h-6 w-6 text-slate-500 transition duration-300 group-hover:-translate-y-0.5 group-hover:text-blue-400" strokeWidth={1.5} aria-hidden="true" />
                </div>

                <h3 className="mt-10 font-display text-2xl font-bold text-white">{s.title}</h3>
                <p className="mt-2 text-[15px] leading-relaxed text-slate-400">{s.description}</p>

                <div className="mt-auto flex items-end justify-between gap-4 pt-6">
                  {s.tags ? (
                    <ul className="flex flex-wrap gap-1.5">
                      {s.tags.map((t) => (
                        <li key={t} className="rounded-md border border-white/[0.08] px-2 py-0.5 font-mono text-[10px] text-slate-400">{t}</li>
                      ))}
                    </ul>
                  ) : <span />}
                  <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full border border-white/[0.12] text-slate-400 transition duration-300 group-hover:border-blue-400 group-hover:bg-blue-500 group-hover:text-white">
                    <ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-px group-hover:-translate-y-px" aria-hidden="true" />
                  </span>
                </div>
              </a>
            </li>
          );
        })}
      </ul>
    </div>
  </section>
);
