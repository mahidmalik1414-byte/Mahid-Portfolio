import React, { useEffect, useRef } from 'react';
import { TOOLS } from '../data/portfolioData';
import { SectionHeading } from './SectionHeading';

const HALF = Math.ceil(TOOLS.length / 2);
const ROWS = [TOOLS.slice(0, HALF), TOOLS.slice(HALF)];

const Pill: React.FC<{ name: string; badge: string; hidden?: boolean }> = ({ name, badge, hidden }) => (
  <li
    title={name}
    aria-hidden={hidden || undefined}
    className="mx-1.5 flex shrink-0 items-center gap-3 rounded-2xl border border-white/[0.08] bg-[#0B0F19] px-4 py-3 transition duration-200 hover:-translate-y-0.5 hover:border-blue-400/40"
  >
    <span className="flex h-8 min-w-8 items-center justify-center rounded-lg bg-blue-500/10 px-1.5 font-mono text-[11px] font-bold text-blue-300">{badge}</span>
    <span className="whitespace-nowrap text-sm font-semibold text-white">{name}</span>
  </li>
);

export const Tools: React.FC = () => {
  const root = useRef<HTMLDivElement>(null);

  // Pause the marquee animations while off-screen.
  useEffect(() => {
    const el = root.current;
    if (!el) return;
    const io = new IntersectionObserver(([e]) => el.classList.toggle('is-paused', !e.isIntersecting));
    io.observe(el);
    return () => io.disconnect();
  }, []);

  return (
    <section id="tools" aria-labelledby="tools-title" className="scroll-mt-16 border-t border-white/[0.06] py-28 lg:py-40">
      <div className="mx-auto max-w-7xl px-5 sm:px-8 lg:px-12">
        <SectionHeading id="tools-title" eyebrow="Stack" title="Tools I Actually Build With" />
      </div>

      <div
        ref={root}
        className="marquee mt-16 space-y-4 overflow-hidden [mask-image:linear-gradient(to_right,transparent,#000_8%,#000_92%,transparent)]"
      >
        {ROWS.map((row, r) => (
          <ul
            key={r}
            className={`marquee-track ${r === 1 ? 'reverse' : ''}`}
            style={{ '--dur': `${r === 0 ? 70 : 80}s` } as React.CSSProperties}
          >
            {[...row, ...row].map((t, i) => (
              <Pill key={`${t.name}-${i}`} {...t} hidden={i >= row.length} />
            ))}
          </ul>
        ))}
      </div>
    </section>
  );
};
