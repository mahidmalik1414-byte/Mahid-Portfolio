import React from 'react';
import { Facebook, Github, Instagram, Linkedin, Mail } from 'lucide-react';
import { SOCIAL_CONFIG, getEmailLink } from '../config/socialConfig';

type Item = { label: string; href: string; icon: React.ElementType; external: boolean };

/**
 * Only real, configured destinations are rendered. Nothing is invented.
 * Facebook replaces GitHub as soon as SOCIAL_CONFIG.FACEBOOK_URL is filled in.
 */
export const getSocialItems = (): Item[] => {
  const items: (Item | null)[] = [
    SOCIAL_CONFIG.INSTAGRAM_URL ? { label: 'Instagram', href: SOCIAL_CONFIG.INSTAGRAM_URL, icon: Instagram, external: true } : null,
    SOCIAL_CONFIG.FACEBOOK_URL
      ? { label: 'Facebook', href: SOCIAL_CONFIG.FACEBOOK_URL, icon: Facebook, external: true }
      : SOCIAL_CONFIG.GITHUB_URL
        ? { label: 'GitHub', href: SOCIAL_CONFIG.GITHUB_URL, icon: Github, external: true }
        : null,
    SOCIAL_CONFIG.LINKEDIN_URL ? { label: 'LinkedIn', href: SOCIAL_CONFIG.LINKEDIN_URL, icon: Linkedin, external: true } : null,
    getEmailLink() ? { label: 'Email', href: getEmailLink()!, icon: Mail, external: false } : null,
  ];
  return items.filter((i): i is Item => i !== null);
};

export const SocialLinks: React.FC<{ className?: string }> = ({ className = '' }) => (
  <ul className={`flex flex-wrap items-center gap-3 ${className}`}>
    {getSocialItems().map(({ label, href, icon: Icon, external }) => (
      <li key={label}>
        <a
          href={href}
          aria-label={external ? `${label} (opens in a new tab)` : `Email ${SOCIAL_CONFIG.CONTACT_EMAIL}`}
          title={label}
          {...(external ? { target: '_blank', rel: 'noopener noreferrer' } : {})}
          className="group flex h-12 w-12 items-center justify-center rounded-full border border-white/[0.16] text-slate-300 transition duration-200 hover:-translate-y-0.5 hover:border-blue-400/70 hover:bg-blue-500/10 hover:text-white active:scale-95"
        >
          <Icon className="h-[18px] w-[18px] transition-transform duration-200 group-hover:scale-110" strokeWidth={1.75} aria-hidden="true" />
        </a>
      </li>
    ))}
  </ul>
);
