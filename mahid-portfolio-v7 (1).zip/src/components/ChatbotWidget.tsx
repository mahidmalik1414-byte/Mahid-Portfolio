import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Bot, X, Send, RotateCcw, Sparkles, ArrowUpRight, Mail, MessageCircle, RefreshCw } from 'lucide-react';
import { SOCIAL_CONFIG, getEmailLink } from '../config/socialConfig';
import { SERVICES, TOOLS } from '../data/portfolioData';

/* -------------------------------------------------------------------------------------------
 * Knowledge base. Every answer only states facts that already appear on this website
 * (title, experience, services, tools, projects) or in socialConfig.ts. No prices, no
 * delivery times, no client names, no results.
 * ----------------------------------------------------------------------------------------- */

type Action = { label: string; kind: 'section' | 'link'; target: string };

interface FAQItem {
  id: string;
  triggers: string[];
  answer: () => string;
  actions?: () => Action[];
}

interface Message {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  time: string;
  actions?: Action[];
  retry?: { text: string; id?: string };
}

const whatsappDisplay = () => {
  const n = SOCIAL_CONFIG.WHATSAPP_NUMBER;
  return n ? `+${n.slice(0, 2)} ${n.slice(2, 5)} ${n.slice(5)}` : '';
};
const instagramHandle = () => {
  const m = SOCIAL_CONFIG.INSTAGRAM_URL.match(/instagram\.com\/([^/?#]+)/);
  return m ? `@${m[1]}` : '';
};
const serviceNames = () => SERVICES.map((s) => s.title).join(', ').replace(/, ([^,]*)$/, ' and $1');
const toolNames = (names: string[]) => TOOLS.filter((t) => names.includes(t.name)).map((t) => t.name);

const contactActions = (): Action[] => {
  const list: Action[] = [{ label: 'Open Contact section', kind: 'section', target: 'contact' }];
  const mail = getEmailLink();
  if (mail) list.unshift({ label: 'Email Mahid', kind: 'link', target: mail });
  return list;
};

const KB: FAQItem[] = [
  {
    id: 'who',
    triggers: ['who is mahid', 'who is mahid malik', 'who are you', 'about mahid', 'about you', 'tell me about', 'introduce', 'background'],
    answer: () =>
      "I'm Mahid's portfolio assistant. Mahid Malik is an AI-Powered Developer focused on building intelligent digital experiences. Mahid works across AI automation, AI voice agents, SaaS, web development, SEO and digital marketing.",
    actions: () => [{ label: 'Read About', kind: 'section', target: 'about' }],
  },
  {
    id: 'what-does',
    triggers: ['what does mahid do', 'what do you do', 'what does he do', 'what he does', 'profession', 'job', 'occupation'],
    answer: () =>
      'Mahid is an AI-Powered Developer who turns complex ideas into useful, modern and efficient digital solutions for businesses, from AI automation and voice agents to SaaS products, websites, SEO and digital marketing.',
    actions: () => [{ label: 'View Services', kind: 'section', target: 'services' }],
  },
  {
    id: 'experience',
    triggers: ['experience', 'how long', 'years', 'how many years', 'how much experience', 'senior', 'junior'],
    answer: () => 'Mahid has 2+ years of experience as an AI-Powered Developer.',
    actions: () => [{ label: 'Read About', kind: 'section', target: 'about' }],
  },
  {
    id: 'services',
    triggers: ['service', 'services', 'offer', 'offerings', 'capabilities', 'help with', 'specialty', 'what can you build'],
    answer: () => `Mahid offers six core services: ${serviceNames()}.`,
    actions: () => [{ label: 'View Core Services', kind: 'section', target: 'services' }],
  },
  {
    id: 'automation',
    triggers: ['automation', 'automate', 'workflow', 'workflows', 'zapier', 'n8n', 'pipeline', 'ai automation'],
    answer: () => {
      const t = toolNames(['n8n', 'OpenAI', 'Webhooks', 'REST APIs']);
      return `Yes. AI Automation is one of Mahid's core services: automating repetitive workflows with intelligent AI systems${t.length ? `, using tools such as ${t.join(', ')}` : ''}.`;
    },
    actions: () => [{ label: 'View Services', kind: 'section', target: 'services' }],
  },
  {
    id: 'voice',
    triggers: ['voice', 'voice agent', 'voice agents', 'voice calling', 'phone agent', 'call agent', 'calling agent', 'ai caller', 'vapi', 'retell'],
    answer: () => {
      const t = toolNames(['Vapi', 'Retell AI']);
      return `Yes. AI Voice Calling Agents is one of Mahid's core services: natural AI phone agents built for real business workflows${t.length ? `, using tools such as ${t.join(' and ')}` : ''}. The voice agent project is in the Work section.`;
    },
    actions: () => [{ label: 'View Work', kind: 'section', target: 'work' }],
  },
  {
    id: 'saas-web',
    triggers: ['saas', 'website', 'websites', 'web dev', 'web development', 'web app', 'frontend', 'landing page', 'ecommerce', 'react', 'next.js', 'software'],
    answer: () => {
      const t = toolNames(['React', 'Next.js', 'TypeScript', 'Tailwind CSS']);
      return `Yes. SaaS Development turns product ideas into scalable SaaS experiences, and Web Development covers fast, responsive websites built for real users${t.length ? `. Mahid builds with ${t.join(', ')}` : ''}.`;
    },
    actions: () => [{ label: 'View Work', kind: 'section', target: 'work' }],
  },
  {
    id: 'seo',
    triggers: ['seo', 'search engine', 'ranking', 'organic', 'keywords', 'local seo', 'technical seo'],
    answer: () => 'SEO is one of the six core services: Technical, On-Page, Local and Off-Page SEO systems.',
    actions: () => [{ label: 'View Services', kind: 'section', target: 'services' }],
  },
  {
    id: 'marketing',
    triggers: ['marketing', 'ads', 'advertising', 'google ads', 'meta ads', 'social media', 'ppc', 'performance marketing'],
    answer: () => 'Digital Marketing is one of the six core services: Google Ads, Meta Ads, social media marketing and performance marketing.',
    actions: () => [{ label: 'View Services', kind: 'section', target: 'services' }],
  },
  {
    id: 'projects',
    triggers: ['project', 'projects', 'portfolio', 'work', 'examples', 'demo', 'case study', 'built before'],
    answer: () =>
      'The Work section shows selected projects across SaaS, voice AI, e-commerce and digital marketing. A project card links to its live demo once one is available; otherwise it says "Demo coming soon".',
    actions: () => [{ label: 'View Work', kind: 'section', target: 'work' }],
  },
  {
    id: 'tools',
    triggers: ['stack', 'tech stack', 'technologies', 'tools', 'languages', 'frameworks', 'build with', 'built with'],
    answer: () => `Mahid builds with tools including ${TOOLS.slice(0, 12).map((t) => t.name).join(', ')} and more. The full list is in the Tools section.`,
    actions: () => [{ label: 'View Tools', kind: 'section', target: 'tools' }],
  },
  {
    id: 'pricing',
    triggers: ['price', 'prices', 'pricing', 'cost', 'costs', 'rate', 'rates', 'budget', 'quote', 'quotation', 'how much', 'fee', 'fees', 'charge', 'estimate', 'estimated'],
    answer: () =>
      "Project pricing depends on your requirements, scope, and timeline. I don't want to give you an inaccurate quote. Please contact Mahid directly to discuss your project and get a suitable estimate. For a custom quote, Mahid will need to review your requirements first.",
    actions: contactActions,
  },
  {
    id: 'timeline',
    triggers: ['timeline', 'turnaround', 'deadline', 'delivery', 'duration', 'how fast', 'how soon', 'when can'],
    answer: () =>
      "Timelines depend on the scope and requirements, so I can't promise a delivery date here. Please contact Mahid directly to discuss your project.",
    actions: contactActions,
  },
  {
    id: 'contact',
    triggers: ['contact', 'email', 'reach', 'talk', 'hire', 'phone', 'whatsapp', 'call', 'message', 'touch', 'instagram', 'facebook', 'social'],
    answer: () => {
      const parts: string[] = [];
      if (SOCIAL_CONFIG.CONTACT_EMAIL) parts.push(`email at ${SOCIAL_CONFIG.CONTACT_EMAIL}`);
      if (whatsappDisplay()) parts.push(`WhatsApp at ${whatsappDisplay()}`);
      if (instagramHandle()) parts.push(`Instagram (${instagramHandle()})`);
      if (SOCIAL_CONFIG.FACEBOOK_URL) parts.push('Facebook');
      return `You can reach Mahid by ${parts.join(', ').replace(/, ([^,]*)$/, ' or $1')}. All the links are in the Contact section.`;
    },
    actions: () => {
      const list = contactActions();
      if (SOCIAL_CONFIG.WHATSAPP_DIRECT_URL) list.push({ label: 'WhatsApp', kind: 'link', target: SOCIAL_CONFIG.WHATSAPP_DIRECT_URL });
      return list;
    },
  },
  {
    id: 'greeting',
    triggers: ['hi', 'hello', 'hey', 'salam', 'assalam', 'good morning', 'good evening'],
    answer: () => "Hello! I'm Mahid's portfolio assistant. Ask me about Mahid's profile, experience, services, projects or how to get in touch.",
  },
];

const byId = (id: string) => KB.find((k) => k.id === id)!;

/** The nine suggested questions, each mapped to its exact answer. */
const SUGGESTIONS: { q: string; id: string }[] = [
  { q: 'Who is Mahid Malik?', id: 'who' },
  { q: 'What does Mahid do?', id: 'what-does' },
  { q: 'How much experience does Mahid have?', id: 'experience' },
  { q: 'What services does Mahid offer?', id: 'services' },
  { q: 'Does Mahid build AI automation systems?', id: 'automation' },
  { q: 'Does Mahid develop AI voice agents?', id: 'voice' },
  { q: 'Does Mahid build SaaS and websites?', id: 'saas-web' },
  { q: 'How can I contact Mahid?', id: 'contact' },
  { q: 'What is the estimated project price?', id: 'pricing' },
];

const FALLBACK: FAQItem = {
  id: 'fallback',
  triggers: [],
  answer: () =>
    "I can answer questions about Mahid's profile, experience, services, projects and contact details. For anything else, please contact Mahid directly.",
  actions: contactActions,
};

const findAnswer = (query: string): FAQItem => {
  const q = ` ${query.toLowerCase().replace(/[?.,!/]/g, ' ').replace(/\s+/g, ' ').trim()} `;
  let best: FAQItem | null = null;
  let top = 0;
  for (const item of KB) {
    let score = 0;
    for (const t of item.triggers) {
      // whole-word / whole-phrase match, so "hi" does not match "this"
      if (q.includes(` ${t} `)) score += t.includes(' ') ? 20 : 10;
    }
    if (score > top) {
      top = score;
      best = item;
    }
  }
  return best && top >= 10 ? best : FALLBACK;
};

const now = () => new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
const WELCOME = "Hi! I'm Mahid's portfolio assistant. Ask me about Mahid's profile, experience, services, projects or contact details.";

interface ChatbotWidgetProps {
  onNavigate?: (sectionId: string) => void;
}

export const ChatbotWidget: React.FC<ChatbotWidgetProps> = ({ onNavigate }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [input, setInput] = useState('');
  const [typing, setTyping] = useState(false);
  const [messages, setMessages] = useState<Message[]>([{ id: 'welcome', sender: 'assistant', text: WELCOME, time: now() }]);

  const bodyRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const launcherRef = useRef<HTMLButtonElement>(null);
  const timer = useRef<number>(0);

  const scrollToEnd = useCallback(() => {
    const el = bodyRef.current;
    if (el) el.scrollTo({ top: el.scrollHeight, behavior: 'smooth' });
  }, []);

  const close = useCallback(() => {
    setIsOpen(false);
    launcherRef.current?.focus({ preventScroll: true });
  }, []);

  useEffect(() => () => window.clearTimeout(timer.current), []);

  useEffect(() => {
    if (!isOpen) return;
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && close();
    window.addEventListener('keydown', onKey);
    const t = window.setTimeout(() => {
      inputRef.current?.focus({ preventScroll: true });
    }, 250);
    return () => {
      window.removeEventListener('keydown', onKey);
      window.clearTimeout(t);
    };
  }, [isOpen, close, scrollToEnd]);

  useEffect(() => {
    // With only the welcome message, keep the top of the conversation in view
    if (messages.length === 1 && !typing) bodyRef.current?.scrollTo({ top: 0 });
    else scrollToEnd();
  }, [messages, typing, scrollToEnd]);

  const ask = (text: string, forcedId?: string, alreadyShown = false) => {
    const q = text.trim();
    if (!q || typing) return;
    if (!alreadyShown) setMessages((m) => [...m, { id: `u-${Date.now()}`, sender: 'user', text: q, time: now() }]);
    setInput('');
    setTyping(true);
    window.clearTimeout(timer.current);
    timer.current = window.setTimeout(() => {
      try {
        const item = forcedId ? byId(forcedId) : findAnswer(q);
        setMessages((m) => [...m, { id: `a-${Date.now()}`, sender: 'assistant', text: item.answer(), time: now(), actions: item.actions?.() }]);
      } catch {
        setMessages((m) => [
          ...m,
          { id: `e-${Date.now()}`, sender: 'assistant', text: 'Sorry, something went wrong while answering. Please try again.', time: now(), retry: { text: q, id: forcedId } },
        ]);
      } finally {
        setTyping(false);
      }
    }, 450);
  };

  const runAction = (a: Action) => {
    if (a.kind === 'link') {
      if (a.target.startsWith('mailto:')) window.location.href = a.target;
      else window.open(a.target, '_blank', 'noopener,noreferrer');
      return;
    }
    onNavigate?.(a.target);
    close();
  };

  const reset = () => {
    window.clearTimeout(timer.current);
    setTyping(false);
    setMessages([{ id: `welcome-${Date.now()}`, sender: 'assistant', text: WELCOME, time: now() }]);
  };

  const showStarter = messages.length === 1;

  return (
    <div className="fixed bottom-[max(1rem,env(safe-area-inset-bottom))] right-[max(1rem,env(safe-area-inset-right))] z-50 sm:bottom-6 sm:right-6">
      {/* Launcher */}
      <button
        ref={launcherRef}
        type="button"
        onClick={() => setIsOpen(true)}
        inert={isOpen}
        aria-label="Ask Mahid: open portfolio assistant"
        aria-expanded={isOpen}
        className={`group relative flex h-12 items-center gap-2.5 rounded-full border border-blue-300/50 bg-gradient-to-r from-blue-600 to-blue-500 pl-2 pr-4 text-white shadow-[0_8px_28px_rgba(37,99,235,0.45)] transition duration-300 hover:from-blue-500 hover:to-cyan-500 active:scale-95 sm:h-14 sm:gap-3 sm:pr-5 assistant-btn ${
          isOpen ? 'pointer-events-none translate-y-2 scale-90 opacity-0' : 'translate-y-0 scale-100 opacity-100'
        }`}
      >
        <span aria-hidden="true" className="assistant-halo pointer-events-none absolute inset-0 rounded-full border border-cyan-300/60" />
        <span className="relative flex h-8 w-8 items-center justify-center rounded-full bg-white/15 sm:h-10 sm:w-10">
          <Bot className="h-4 w-4 sm:h-5 sm:w-5" aria-hidden="true" />
          <span className="absolute -right-0.5 -top-0.5 h-2.5 w-2.5 rounded-full border-2 border-blue-600 bg-emerald-400" />
        </span>
        <span className="assistant-label text-left leading-tight">
          <span className="flex items-center gap-1.5 text-sm font-bold">
            Ask Mahid <Sparkles className="h-3.5 w-3.5 text-cyan-200" aria-hidden="true" />
          </span>
          <span className="hidden text-[10px] text-blue-100/80 sm:block">Portfolio Assistant</span>
        </span>
      </button>

      {/* Panel: always mounted so it can animate in and out; inert while closed */}
      <div
        role="dialog"
        aria-label="Portfolio Assistant chat"
        aria-hidden={!isOpen}
        inert={!isOpen}
        className={`absolute bottom-0 right-0 flex h-[min(620px,calc(100dvh-2rem))] w-[min(410px,calc(100vw-2rem))] origin-bottom-right flex-col overflow-hidden rounded-3xl border border-white/[0.14] bg-[#0A0D18] shadow-[0_20px_60px_rgba(0,0,0,0.8),0_0_24px_rgba(59,130,246,0.18)] transition duration-300 ease-out ${
          isOpen ? 'visible translate-y-0 scale-100 opacity-100' : 'invisible translate-y-3 scale-95 opacity-0'
        }`}
      >
        {/* Header */}
        <div className="flex shrink-0 items-center justify-between gap-2 border-b border-white/[0.08] bg-[#0D1222] px-4 py-3">
          <div className="flex min-w-0 items-center gap-3">
            <span className="relative flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-tr from-blue-600 to-cyan-500 text-white">
              <Bot className="h-5 w-5" aria-hidden="true" />
              <span className="absolute -bottom-0.5 -right-0.5 h-2.5 w-2.5 rounded-full border-2 border-[#0D1222] bg-emerald-400" />
            </span>
            <div className="min-w-0">
              <h3 className="truncate font-display text-sm font-bold text-white">Mahid&apos;s Assistant</h3>
              <p className="truncate text-[11px] text-slate-400">Instant answers about Mahid</p>
            </div>
          </div>
          <div className="flex shrink-0 items-center gap-1.5">
            <button
              type="button"
              onClick={reset}
              className="flex h-11 w-11 items-center justify-center rounded-xl text-slate-400 transition-colors hover:bg-white/[0.08] hover:text-white"
              aria-label="Restart conversation"
              title="Restart conversation"
            >
              <RotateCcw className="h-4 w-4" aria-hidden="true" />
            </button>
            <button
              type="button"
              onClick={close}
              className="flex h-11 w-11 items-center justify-center rounded-xl border border-white/[0.18] bg-white/[0.07] text-white transition-colors hover:bg-white/[0.16]"
              aria-label="Close chat"
              title="Close (Esc)"
            >
              <X className="h-5 w-5" strokeWidth={2.25} aria-hidden="true" />
            </button>
          </div>
        </div>

        {/* Messages */}
        <div ref={bodyRef} className="min-h-0 flex-1 space-y-4 overflow-y-auto overscroll-contain p-4" aria-live="polite">
          {messages.map((msg) => (
            <div key={msg.id} className={`flex flex-col gap-1 ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}>
              <div
                className={`max-w-[90%] break-words rounded-2xl px-4 py-3 text-[13px] leading-relaxed ${
                  msg.sender === 'user' ? 'bg-blue-600 text-white' : 'border border-white/[0.1] bg-[#121727] text-slate-200'
                }`}
              >
                <p>{msg.text}</p>
                {msg.actions && msg.actions.length > 0 && (
                  <div className="mt-3 flex flex-wrap gap-2 border-t border-white/[0.08] pt-3">
                    {msg.actions.map((a) => (
                      <button
                        key={a.label}
                        type="button"
                        onClick={() => runAction(a)}
                        className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl border border-cyan-400/30 bg-cyan-400/[0.08] px-3 text-xs font-semibold text-cyan-200 transition-colors hover:bg-cyan-400/[0.18]"
                      >
                        {a.target.startsWith('mailto:') ? <Mail className="h-3.5 w-3.5" aria-hidden="true" /> : a.label === 'WhatsApp' ? <MessageCircle className="h-3.5 w-3.5" aria-hidden="true" /> : null}
                        {a.label}
                        <ArrowUpRight className="h-3 w-3" aria-hidden="true" />
                      </button>
                    ))}
                  </div>
                )}
                {msg.retry && (
                  <button
                    type="button"
                    onClick={() => ask(msg.retry!.text, msg.retry!.id, true)}
                    className="mt-3 inline-flex min-h-[40px] items-center gap-1.5 rounded-xl border border-white/[0.18] px-3 text-xs font-semibold text-white hover:bg-white/[0.08]"
                  >
                    <RefreshCw className="h-3.5 w-3.5" aria-hidden="true" />
                    Try again
                  </button>
                )}
              </div>
              <span className="px-1 font-mono text-[10px] text-slate-500">{msg.time}</span>
            </div>
          ))}

          {showStarter && !typing && (
            <div>
              <p className="mb-2 font-mono text-[10px] uppercase tracking-wider text-slate-500">Suggested questions</p>
              <div className="flex flex-wrap gap-2">
                {SUGGESTIONS.map((s) => (
                  <button
                    key={s.id}
                    type="button"
                    onClick={() => ask(s.q, s.id)}
                    className="min-h-[40px] rounded-xl border border-white/[0.12] bg-white/[0.04] px-3 py-2 text-left text-xs text-slate-200 transition-colors hover:border-blue-400/50 hover:bg-blue-500/10 hover:text-white active:scale-[0.98]"
                  >
                    {s.q}
                  </button>
                ))}
              </div>
            </div>
          )}

          {typing && (
            <div className="flex w-20 items-center justify-center gap-1.5 rounded-2xl border border-white/[0.1] bg-[#121727] px-3 py-3.5" role="status" aria-label="Assistant is typing">
              <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-cyan-400" />
              <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-cyan-400 [animation-delay:0.15s]" />
              <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-cyan-400 [animation-delay:0.3s]" />
            </div>
          )}
        </div>

        {/* More questions once the conversation has started */}
        {!showStarter && (
          <div className="flex shrink-0 gap-2 overflow-x-auto border-t border-white/[0.06] bg-black/30 px-3 py-2 no-scrollbar">
            {SUGGESTIONS.map((s) => (
              <button
                key={s.id}
                type="button"
                onClick={() => ask(s.q, s.id)}
                disabled={typing}
                className="min-h-[40px] shrink-0 whitespace-nowrap rounded-full border border-white/[0.12] bg-white/[0.04] px-3.5 text-xs text-slate-300 transition-colors hover:border-blue-400/50 hover:text-white disabled:opacity-50"
              >
                {s.q}
              </button>
            ))}
          </div>
        )}

        {/* Input: 16px text so iOS does not zoom on focus */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            ask(input);
          }}
          className="flex shrink-0 items-center gap-2 border-t border-white/[0.08] bg-[#0D1222] p-3"
        >
          <input
            ref={inputRef}
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask about Mahid, services, contact…"
            aria-label="Your question"
            enterKeyHint="send"
            className="h-11 min-w-0 flex-1 rounded-xl border border-white/[0.12] bg-black/50 px-3.5 text-base text-white placeholder-slate-500 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
          />
          <button
            type="submit"
            disabled={!input.trim() || typing}
            className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-blue-600 text-white transition hover:bg-blue-500 active:scale-95 disabled:opacity-40"
            aria-label="Send message"
          >
            <Send className="h-4 w-4" aria-hidden="true" />
          </button>
        </form>
      </div>
    </div>
  );
};
