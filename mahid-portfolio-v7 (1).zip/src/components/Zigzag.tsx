import React, { useRef } from 'react';
import { usePauseOffscreen } from '../hooks/usePauseOffscreen';

// Decorative divider. Uniform scaling (slice) keeps the stroke weight even on every screen.
const PATH = 'M0 62 L170 62 L215 76 L262 62 L470 62 L500 50 L532 74 L570 62 L760 62 L815 22 L872 86 L925 62 L1200 62';

export const Zigzag: React.FC = () => {
  const ref = useRef<HTMLDivElement>(null);
  usePauseOffscreen(ref);
  return (
    <div ref={ref} className="reveal-on-scroll pointer-events-none mt-20 w-full lg:mt-28" aria-hidden="true">
      <svg viewBox="0 0 1200 100" preserveAspectRatio="xMidYMid slice" className="block h-16 w-full sm:h-20 lg:h-24">
        <g fill="none" strokeLinecap="round" strokeLinejoin="round">
          <path d={PATH} stroke="rgba(96,165,250,0.16)" strokeWidth="1.2" />
          <path d={PATH} pathLength={1} stroke="rgba(59,130,246,0.22)" strokeWidth="6" className="zz-draw" />
          <path d={PATH} pathLength={1} stroke="#60a5fa" strokeWidth="1.6" className="zz-draw" />
          <path d={PATH} pathLength={1} stroke="#bae6fd" strokeWidth="2.4" className="zz-pulse" />
        </g>
      </svg>
    </div>
  );
};
