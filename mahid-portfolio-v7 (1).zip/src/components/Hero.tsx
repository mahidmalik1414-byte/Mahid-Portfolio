import React from 'react';
import { ArrowRight, ArrowUpRight } from 'lucide-react';
import { HeroEcosystem } from './HeroEcosystem';
import { SOCIAL_CONFIG } from '../config/socialConfig';

const d = (ms: number) => ({ '--d': `${ms}ms` } as React.CSSProperties);

export const Hero: React.FC = () => (
  <section id="hero" className="relative overflow-hidden pb-16 pt-28 sm:pt-32 lg:pb-24 lg:pt-36">
    {/* One static depth gradient, no blur filters */}
    <div
      aria-hidden="true"
      className="pointer-events-none absolute -right-40 top-0 h-[720px] w-[720px]"
      style={{ background: 'radial-gradient(closest-side, rgba(37,99,235,0.10), transparent)' }}
    />

    <div className="relative mx-auto grid max-w-7xl grid-cols-1 items-center gap-14 px-5 sm:px-8 lg:grid-cols-12 lg:gap-10 lg:px-12">
      <div className="lg:col-span-7">
        <div
          className="hero-in inline-flex max-w-full flex-wrap items-center gap-x-2 gap-y-1 rounded-2xl border border-white/[0.1] bg-white/[0.04] px-4 py-2 text-xs sm:rounded-full font-medium text-slate-300 sm:text-sm"
          style={d(0)}
        >
          <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" aria-hidden="true" />
          <span className="font-semibold text-blue-300">AI-Powered Developer</span>
          <span className="hidden text-slate-500 sm:inline" aria-hidden="true">·</span>
          <span>Available for projects</span>
        </div>

        <h1
          className="hero-in mt-6 font-display text-[clamp(2.35rem,9.5vw,3.6rem)] font-extrabold leading-[1.03] text-white sm:text-[clamp(3rem,7vw,4.4rem)] lg:text-[clamp(3.2rem,4.7vw,4.9rem)]"
          style={d(100)}
        >
          I Build Intelligent Digital Experiences{' '}
          <span className="bg-gradient-to-r from-blue-400 to-cyan-300 bg-clip-text text-transparent">With AI.</span>
        </h1>

        <p
          className="hero-in mt-6 max-w-2xl font-mono text-[13px] leading-relaxed text-slate-400 sm:text-sm"
          style={d(220)}
        >
          AI Automation • AI Agents • SaaS • Web Development • SEO • Digital Marketing
        </p>

        <div className="hero-in mt-9 flex flex-col gap-3 sm:flex-row" style={d(340)}>
          <a
            href="#work"
            className="btn-lift group inline-flex h-12 items-center justify-center gap-2 rounded-xl bg-blue-600 px-7 text-sm font-semibold text-white hover:bg-blue-500"
          >
            View My Work
            <ArrowRight className="h-4 w-4 transition-transform duration-200 group-hover:translate-x-1" />
          </a>
          <a
            href="#contact"
            className="btn-lift group inline-flex h-12 items-center justify-center gap-2 rounded-xl border border-white/[0.16] px-7 text-sm font-semibold text-white hover:border-white/35 hover:bg-white/[0.06]"
          >
            Let&apos;s Work Together
            <ArrowUpRight className="h-4 w-4 transition-transform duration-200 group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
          </a>
        </div>
      </div>

      <div className="lg:col-span-5">
        <HeroEcosystem />
      </div>
    </div>
  </section>
);
