import React from 'react';
import portrait from '../assets/images/mahid-portrait.webp';
import { SERVICES } from '../data/portfolioData';
import { Zigzag } from './Zigzag';

const METRICS = [
  { value: '2+ Years', label: 'Experience' },
  { value: String(SERVICES.length), label: 'Core Services' },
  { value: 'AI-Powered', label: 'Approach' },
  { value: 'End-to-End', label: 'Development' },
];

export const About: React.FC = () => (
  <section id="about" aria-labelledby="about-title" className="scroll-mt-16 border-t border-white/[0.06] pt-28 lg:pt-40">
    <div className="mx-auto max-w-7xl px-5 sm:px-8 lg:px-12">
      <div className="grid grid-cols-1 gap-14 lg:grid-cols-12 lg:gap-16">
        {/* Left: label, heading, photo */}
        <div className="reveal-on-scroll min-w-0 lg:col-span-5">
          <p className="font-mono text-xs uppercase tracking-[0.2em] text-blue-400">About me</p>
          <h2
            id="about-title"
            className="mt-4 font-display text-[clamp(2rem,6.5vw,3.5rem)] font-extrabold leading-[1.05] text-white lg:text-[clamp(2.2rem,3.6vw,3.4rem)]"
          >
            Building With AI.{' '}
            <span className="block text-blue-300">Creating With Purpose.</span>
          </h2>

          <div className="relative mt-10 w-full max-w-[300px] sm:max-w-[340px]">
            <div
              aria-hidden="true"
              className="absolute -inset-3 rounded-[2rem] opacity-70"
              style={{ background: 'radial-gradient(closest-side, rgba(37,99,235,0.22), transparent)' }}
            />
            <div className="relative aspect-square overflow-hidden rounded-3xl border border-white/[0.12] bg-slate-900 shadow-2xl shadow-black/60">
              <img
                src={portrait}
                alt="Mahid Malik, AI-Powered Developer, wearing glasses and a beige shirt at his desk"
                width={720}
                height={720}
                loading="lazy"
                decoding="async"
                className="h-full w-full object-cover"
              />
            </div>
          </div>
        </div>

        {/* Right: introduction + metrics */}
        <div className="reveal-on-scroll delay-100 min-w-0 lg:col-span-7">
          <p className="font-display text-xl font-bold text-blue-300 sm:text-2xl">AI-Powered Developer</p>
          <p className="mt-5 max-w-2xl text-base leading-relaxed text-slate-300 sm:text-lg">
            I&apos;m Mahid Malik, an AI-powered developer focused on building intelligent digital experiences. I work across
            AI automation, AI voice agents, SaaS, web development, SEO, and digital marketing. My goal is to turn complex
            ideas into useful, modern, and efficient digital solutions for businesses.
          </p>

          <dl className="mt-10 grid grid-cols-2 gap-px overflow-hidden rounded-2xl border border-white/[0.1] bg-white/[0.1] xl:grid-cols-4">
            {METRICS.map((m) => (
              <div key={m.label} className="min-w-0 bg-[#080B12] p-5 sm:p-6 xl:p-5">
                <dd className="whitespace-nowrap font-display text-lg font-bold text-white min-[380px]:text-xl sm:text-2xl xl:text-[clamp(1rem,1.3vw,1.3rem)]">{m.value}</dd>
                <dt className="mt-1.5 font-mono text-[11px] uppercase tracking-wider text-slate-400">{m.label}</dt>
              </div>
            ))}
          </dl>
        </div>
      </div>
    </div>

    <Zigzag />
  </section>
);
