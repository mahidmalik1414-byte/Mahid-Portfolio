import React, { useEffect, useRef } from 'react';
import { Bot, Workflow, Layout, Globe, TrendingUp, PhoneCall } from 'lucide-react';
import { usePauseOffscreen } from '../hooks/usePauseOffscreen';

// Satellite nodes on a ring (percent of the square stage). `k` = parallax depth.
const NODES = [
  { label: 'Automation', icon: Workflow, x: 50, y: 14, t: '7s', o: '0s', k: 0.5, draw: 0.55, pulse: 1.7 },
  { label: 'Voice Agents', icon: PhoneCall, x: 84.2, y: 38.9, t: '8s', o: '-2s', k: 0.8, draw: 0.7, pulse: 2.6 },
  { label: 'Marketing', icon: TrendingUp, x: 71.2, y: 79.1, t: '6.5s', o: '-4s', k: 0.6, draw: 0.85, pulse: 3.3 },
  { label: 'Web', icon: Globe, x: 28.8, y: 79.1, t: '7.5s', o: '-1s', k: 0.7, draw: 1.0, pulse: 2.1 },
  { label: 'SaaS', icon: Layout, x: 15.8, y: 38.9, t: '8.5s', o: '-3s', k: 0.9, draw: 1.15, pulse: 3.0 },
];

const MAX_TILT = 6; // degrees
const MAX_SHIFT = 8; // px

export const HeroEcosystem: React.FC = () => {
  const stage = useRef<HTMLDivElement>(null);
  const tilt = useRef<HTMLDivElement>(null);
  usePauseOffscreen(stage);

  // Pointer parallax: fine pointers only, never with reduced motion. One rAF-throttled
  // handler writes CSS variables on the stage; React never re-renders.
  useEffect(() => {
    const el = stage.current;
    const target = tilt.current;
    if (!el || !target) return;
    const canHover = window.matchMedia('(hover: hover) and (pointer: fine)').matches;
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (!canHover || reduce) return;

    let frame = 0;
    let nx = 0;
    let ny = 0;
    const apply = () => {
      frame = 0;
      target.style.setProperty('--rx', `${(-ny * MAX_TILT).toFixed(2)}deg`);
      target.style.setProperty('--ry', `${(nx * MAX_TILT).toFixed(2)}deg`);
      target.style.setProperty('--tx', `${(nx * MAX_SHIFT).toFixed(2)}px`);
      target.style.setProperty('--ty', `${(ny * MAX_SHIFT).toFixed(2)}px`);
    };
    const onMove = (e: PointerEvent) => {
      const r = el.getBoundingClientRect();
      nx = Math.max(-1, Math.min(1, (e.clientX - (r.left + r.width / 2)) / (r.width / 2)));
      ny = Math.max(-1, Math.min(1, (e.clientY - (r.top + r.height / 2)) / (r.height / 2)));
      if (!frame) frame = requestAnimationFrame(apply);
    };
    const onLeave = () => {
      nx = 0;
      ny = 0;
      if (!frame) frame = requestAnimationFrame(apply);
    };
    el.addEventListener('pointermove', onMove, { passive: true });
    el.addEventListener('pointerleave', onLeave);
    return () => {
      el.removeEventListener('pointermove', onMove);
      el.removeEventListener('pointerleave', onLeave);
      if (frame) cancelAnimationFrame(frame);
    };
  }, []);

  return (
    <div
      ref={stage}
      className="relative mx-auto aspect-square w-full max-w-[min(440px,100%)] lg:max-w-none"
      role="img"
      aria-label="Connected ecosystem: AI at the centre, linked to Automation, Voice Agents, Marketing, Web and SaaS"
    >
      <div ref={tilt} className="eco-tilt absolute inset-0">
        {/* Connectors. Solid strokes only: a gradient stroke on a perfectly vertical line has a
            zero-width bounding box and silently fails to render, which hid the Automation line. */}
        <svg viewBox="0 0 100 100" className="absolute inset-0 h-full w-full overflow-visible" aria-hidden="true">
          <circle cx="50" cy="50" r="36" fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="0.3" strokeDasharray="0.8 1.8" />
          {NODES.map((n) => {
            const d = `M50 50 L${n.x} ${n.y}`;
            return (
              <g key={n.label} strokeLinecap="round" fill="none">
                <path d={d} pathLength={1} stroke="rgba(96,165,250,0.55)" strokeWidth="0.45" className="eco-line" style={{ '--d': `${n.draw}s` } as React.CSSProperties} />
                {/* soft glow + travelling light pulse */}
                <path d={d} pathLength={1} stroke="rgba(103,232,249,0.22)" strokeWidth="1.5" className="eco-pulse" style={{ '--d2': `${n.pulse}s`, '--t': '3.8s' } as React.CSSProperties} />
                <path d={d} pathLength={1} stroke="#a5f3fc" strokeWidth="0.6" className="eco-pulse" style={{ '--d2': `${n.pulse}s`, '--t': '3.8s' } as React.CSSProperties} />
              </g>
            );
          })}
        </svg>

        {/* Core */}
        <div className="eco-anchor" style={{ left: '50%', top: '50%' }}>
          <div className="eco-depth" style={{ '--k': 0.2 } as React.CSSProperties}>
            <div className="eco-in relative" style={{ '--d': '300ms' } as React.CSSProperties}>
              <span
                aria-hidden="true"
                className="eco-core-glow absolute -inset-8 rounded-full"
                style={{ background: 'radial-gradient(closest-side, rgba(59,130,246,0.38), transparent)' }}
              />
              <div className="relative flex h-20 w-20 items-center justify-center rounded-3xl border border-blue-400/45 bg-[#0B1224] sm:h-24 sm:w-24 lg:h-28 lg:w-28">
                <Bot className="h-9 w-9 text-cyan-300 sm:h-11 sm:w-11 lg:h-12 lg:w-12" strokeWidth={1.5} aria-hidden="true" />
                <span className="absolute -bottom-7 font-mono text-[11px] tracking-widest text-blue-300">AI</span>
              </div>
            </div>
          </div>
        </div>

        {/* Satellites */}
        {NODES.map((n, i) => {
          const Icon = n.icon;
          return (
            <div key={n.label} className="eco-anchor" style={{ left: `${n.x}%`, top: `${n.y}%` }}>
              <div className="eco-depth" style={{ '--k': n.k } as React.CSSProperties}>
                <div className="eco-in" style={{ '--d': `${450 + i * 110}ms` } as React.CSSProperties}>
                  <div
                    className="eco-float group flex items-center gap-1.5 rounded-xl border border-white/[0.12] bg-[#0E121B] px-2.5 py-1.5 shadow-lg shadow-black/50 transition-colors duration-200 hover:border-blue-400/50 sm:gap-2 sm:px-3 sm:py-2"
                    style={{ '--t': n.t, '--o': n.o } as React.CSSProperties}
                  >
                    <Icon className="h-3.5 w-3.5 shrink-0 text-blue-400 transition-transform duration-200 group-hover:scale-110 sm:h-4 sm:w-4" aria-hidden="true" />
                    <span className="whitespace-nowrap text-[11px] font-medium text-slate-200 sm:text-xs">{n.label}</span>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
