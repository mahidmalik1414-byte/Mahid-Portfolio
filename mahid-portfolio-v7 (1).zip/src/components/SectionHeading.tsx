import React from 'react';

export const SectionHeading: React.FC<{ eyebrow: string; title: string; subtitle?: string; id?: string }> = ({
  eyebrow, title, subtitle, id,
}) => (
  <div className="reveal-on-scroll max-w-2xl">
    <p className="font-mono text-xs uppercase tracking-[0.2em] text-blue-400">{eyebrow}</p>
    <h2 id={id} className="mt-4 font-display text-3xl font-extrabold text-white sm:text-5xl">{title}</h2>
    {subtitle && <p className="mt-5 text-base leading-relaxed text-slate-400 sm:text-lg">{subtitle}</p>}
  </div>
);
