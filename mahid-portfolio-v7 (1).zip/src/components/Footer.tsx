import React from 'react';
import { SocialLinks } from './SocialLinks';

const PAGES = [
  { id: 'about', label: 'About' },
  { id: 'services', label: 'Services' },
  { id: 'work', label: 'Projects' },
  { id: 'process', label: 'Process' },
  { id: 'contact', label: 'Contact' },
];

export const Footer: React.FC = () => (
  <footer className="reveal-on-scroll border-t border-white/[0.08] pb-28 pt-14 sm:pb-16 lg:py-16">
    <div className="mx-auto grid max-w-7xl grid-cols-1 gap-10 px-5 sm:px-8 md:grid-cols-[1.2fr_auto_1.2fr] md:items-center md:gap-8 lg:px-12">
      {/* Left: brand */}
      <div>
        <a href="#hero" className="inline-flex min-h-[44px] items-center font-display text-xl font-bold tracking-tight text-white" aria-label="Mahid Malik, back to top">
          Mahid<span className="text-blue-400">.</span>Malik
        </a>
        <p className="mt-3 text-sm text-slate-400">AI Automation · AI Agents · Web Development</p>
        <p className="mt-5 text-xs text-slate-500">© {new Date().getFullYear()} Mahid.Malik. All rights reserved.</p>
      </div>

      {/* Center: navigation */}
      <nav aria-label="Footer" className="md:justify-self-center">
        <ul className="flex flex-wrap gap-x-6 gap-y-1 text-sm text-slate-400">
          {PAGES.map((p) => (
            <li key={p.id}>
              <a href={`#${p.id}`} className="inline-flex min-h-[44px] items-center px-1 transition-colors duration-200 hover:text-white">
                {p.label}
              </a>
            </li>
          ))}
        </ul>
      </nav>

      {/* Right: socials */}
      <SocialLinks className="md:justify-self-end" />
    </div>
  </footer>
);
