import React, { useState } from 'react';
import { ArrowUpRight, Check, Copy, Mail } from 'lucide-react';
import { SOCIAL_CONFIG, getEmailLink, getWhatsAppLink } from '../config/socialConfig';
import { SocialLinks } from './SocialLinks';

const EmailCard: React.FC = () => {
  const [copied, setCopied] = useState(false);
  const email = SOCIAL_CONFIG.CONTACT_EMAIL;

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(email);
    } catch {
      // Fallback for browsers without the async clipboard API
      const ta = document.createElement('textarea');
      ta.value = email;
      ta.setAttribute('readonly', '');
      ta.style.position = 'fixed';
      ta.style.opacity = '0';
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      document.body.removeChild(ta);
    }
    setCopied(true);
    window.setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="reveal-on-scroll delay-200 mt-14 flex max-w-4xl flex-col gap-6 rounded-3xl border border-white/[0.08] bg-[#0B0F19] p-7 sm:p-9 lg:flex-row lg:items-center lg:justify-between">
      <div className="flex min-w-0 flex-col items-start gap-4 sm:flex-row sm:items-center sm:gap-5">
        <span className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl border border-blue-400/30 bg-blue-500/10 text-blue-300">
          <Mail className="h-6 w-6" strokeWidth={1.6} aria-hidden="true" />
        </span>
        <div className="min-w-0">
          <p className="font-mono text-[11px] uppercase tracking-[0.2em] text-slate-500">Email</p>
          <p className="mt-1.5 break-all text-[15px] font-semibold text-white sm:break-normal sm:text-xl">{email}</p>
        </div>
      </div>

      <div className="flex flex-col gap-3 sm:flex-row lg:shrink-0">
        <a
          href={getEmailLink() ?? undefined}
          className="group inline-flex h-12 items-center justify-center gap-2 rounded-xl bg-blue-600 px-6 text-sm font-semibold text-white transition duration-200 hover:-translate-y-0.5 hover:bg-blue-500 active:translate-y-0 active:scale-[0.98]"
        >
          Email Me
          <ArrowUpRight className="h-4 w-4 transition-transform duration-200 group-hover:-translate-y-0.5 group-hover:translate-x-0.5" aria-hidden="true" />
        </a>
        <button
          type="button"
          onClick={copy}
          className="inline-flex h-12 items-center justify-center gap-2 rounded-xl border border-white/[0.14] px-5 text-sm font-semibold text-white transition duration-200 hover:border-white/30 hover:bg-white/[0.05] active:scale-[0.98]"
        >
          {copied ? <Check className="h-4 w-4 text-emerald-400" aria-hidden="true" /> : <Copy className="h-4 w-4" aria-hidden="true" />}
          <span aria-live="polite">{copied ? 'Copied' : 'Copy'}</span>
        </button>
      </div>
    </div>
  );
};

export const Contact: React.FC = () => (
  <section id="contact" aria-labelledby="contact-title" className="relative scroll-mt-16 border-t border-white/[0.06] py-28 lg:py-44">
    <div
      aria-hidden="true"
      className="pointer-events-none absolute inset-x-0 bottom-0 h-[420px]"
      style={{ background: 'radial-gradient(60% 100% at 50% 100%, rgba(37,99,235,0.10), transparent)' }}
    />
    <div className="relative mx-auto max-w-7xl px-5 sm:px-8 lg:px-12">
      <p className="reveal-on-scroll font-mono text-xs uppercase tracking-[0.2em] text-blue-400">Contact</p>
      <h2 id="contact-title" className="reveal-on-scroll delay-100 mt-4 max-w-4xl font-display text-5xl font-extrabold leading-[1.02] text-white sm:text-7xl lg:text-8xl">
        Let&apos;s Build Something<span className="text-blue-400">.</span>
      </h2>

      <div className="reveal-on-scroll delay-200 mt-10">
        <a
          href={getWhatsAppLink()}
          target="_blank"
          rel="noopener noreferrer"
          className="group inline-flex h-12 items-center justify-center gap-2 rounded-xl bg-blue-600 px-8 text-sm font-semibold text-white transition duration-200 hover:-translate-y-0.5 hover:bg-blue-500 active:translate-y-0 active:scale-[0.98]"
        >
          Start a Project
          <ArrowUpRight className="h-4 w-4 transition-transform duration-200 group-hover:-translate-y-0.5 group-hover:translate-x-0.5" aria-hidden="true" />
        </a>
      </div>

      <EmailCard />

      <div className="reveal-on-scroll delay-300 mt-16 max-w-4xl border-t border-white/[0.08] pt-10">
        <p className="font-mono text-[11px] uppercase tracking-[0.25em] text-slate-500">Find me elsewhere</p>
        <SocialLinks className="mt-5" />
      </div>
    </div>
  </section>
);
