import React from 'react';
import { PROCESS } from '../data/portfolioData';
import { SectionHeading } from './SectionHeading';

export const Process: React.FC = () => (
  <section id="process" aria-labelledby="process-title" className="scroll-mt-16 border-t border-white/[0.06] py-28 lg:py-40">
    <div className="mx-auto max-w-7xl px-5 sm:px-8 lg:px-12">
      <SectionHeading id="process-title" eyebrow="Process" title="How I Work" />
      <ol className="mt-16 grid grid-cols-1 gap-12 sm:grid-cols-2 lg:grid-cols-4 lg:gap-10">
        {PROCESS.map((s, i) => (
          <li key={s.number} className="reveal-on-scroll relative border-t border-white/[0.12] pt-7" style={{ transitionDelay: `${i * 90}ms` }}>
            <span className="font-mono text-sm text-blue-400">{s.number}</span>
            <h3 className="mt-4 font-display text-2xl font-bold text-white">{s.title}</h3>
            <p className="mt-2 text-[15px] text-slate-400">{s.description}</p>
          </li>
        ))}
      </ol>
    </div>
  </section>
);
