import React, { useRef, useState } from 'react';
import { Play, Pause, RotateCcw } from 'lucide-react';
import { SOCIAL_CONFIG } from '../config/socialConfig';

const fmt = (s: number) => {
  if (!Number.isFinite(s)) return '0:00';
  return `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`;
};

/**
 * Plays ONLY the real recording at SOCIAL_CONFIG.VOICE_AGENT_AUDIO_PATH.
 * No synthesized voice, no autoplay. If the file is missing the controls are disabled
 * and the card says so honestly.
 */
export const RecordedDemo: React.FC = () => {
  const ref = useRef<HTMLAudioElement>(null);
  const [status, setStatus] = useState<'loading' | 'ready' | 'missing'>('loading');
  const [playing, setPlaying] = useState(false);
  const [time, setTime] = useState(0);
  const [duration, setDuration] = useState(0);

  const ready = status === 'ready';
  const toggle = () => {
    const a = ref.current;
    if (!a || !ready) return;
    if (a.paused) a.play().catch(() => setPlaying(false));
    else a.pause();
  };
  const replay = () => {
    const a = ref.current;
    if (!a || !ready) return;
    a.currentTime = 0;
    a.play().catch(() => setPlaying(false));
  };
  const pct = duration ? (time / duration) * 100 : 0;

  return (
    <div className="rounded-2xl border border-white/[0.08] bg-black/30 p-4">
      <audio
        ref={ref}
        src={SOCIAL_CONFIG.VOICE_AGENT_AUDIO_PATH}
        preload="metadata"
        onLoadedMetadata={(e) => { setDuration(e.currentTarget.duration); setStatus('ready'); }}
        onError={() => setStatus('missing')}
        onTimeUpdate={(e) => setTime(e.currentTarget.currentTime)}
        onPlay={() => setPlaying(true)}
        onPause={() => setPlaying(false)}
        onEnded={() => setPlaying(false)}
      />

      <div className="flex items-center justify-between">
        <span className="rounded-full border border-blue-400/25 bg-blue-500/10 px-2.5 py-0.5 font-mono text-[10px] text-blue-300">Recorded Demo</span>
        {status === 'missing' && <span className="text-[11px] text-slate-500">Recording coming soon</span>}
      </div>

      <div className="mt-4 flex items-center gap-3">
        <button
          type="button"
          onClick={toggle}
          disabled={!ready}
          aria-label={playing ? 'Pause recording' : 'Play recording'}
          className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-blue-600 text-white transition duration-200 hover:scale-105 hover:bg-blue-500 active:scale-95 disabled:cursor-not-allowed disabled:bg-white/10 disabled:text-slate-500 disabled:hover:scale-100"
        >
          {playing ? <Pause className="h-4 w-4 fill-current" /> : <Play className="ml-0.5 h-4 w-4 fill-current" />}
        </button>

        <div className="min-w-0 flex-1">
          <input
            type="range"
            min={0}
            max={duration || 1}
            step={0.1}
            value={time}
            disabled={!ready}
            aria-label="Seek recording"
            onChange={(e) => { if (ref.current) ref.current.currentTime = Number(e.target.value); }}
            className="range-progress w-full"
            style={{ '--p': `${pct}%` } as React.CSSProperties}
          />
          <div className="mt-1.5 flex justify-between font-mono text-[11px] text-slate-500">
            <span>{fmt(time)}</span>
            <span>{fmt(duration)}</span>
          </div>
        </div>

        <button
          type="button"
          onClick={replay}
          disabled={!ready}
          aria-label="Replay from start"
          className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full border border-white/[0.12] text-slate-300 transition duration-200 hover:bg-white/[0.08] active:scale-95 disabled:cursor-not-allowed disabled:opacity-40"
        >
          <RotateCcw className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
};
