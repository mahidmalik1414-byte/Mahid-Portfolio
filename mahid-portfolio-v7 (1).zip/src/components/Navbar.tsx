import React, { useEffect, useRef, useState } from 'react';
import { Menu, X, ArrowUpRight } from 'lucide-react';

const LINKS = [
  { id: 'hero', label: 'Home' },
  { id: 'about', label: 'About' },
  { id: 'services', label: 'Services' },
  { id: 'work', label: 'Work' },
  { id: 'contact', label: 'Contact' },
];

export const Navbar: React.FC = () => {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState('hero');
  const sentinel = useRef<HTMLDivElement>(null);

  // Glass state: a 1px sentinel at the top of the page, no scroll listener.
  useEffect(() => {
    const el = sentinel.current;
    if (!el) return;
    const io = new IntersectionObserver(([e]) => setScrolled(!e.isIntersecting));
    io.observe(el);
    return () => io.disconnect();
  }, []);

  // Active link: observe sections, no scroll listener.
  useEffect(() => {
    const io = new IntersectionObserver(
      (entries) => entries.forEach((e) => e.isIntersecting && setActive(e.target.id)),
      { rootMargin: '-45% 0px -50% 0px' }
    );
    LINKS.forEach((l) => {
      const el = document.getElementById(l.id);
      if (el) io.observe(el);
    });
    return () => io.disconnect();
  }, []);

  // Escape closes the mobile menu; lock body scroll while open.
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setOpen(false);
    window.addEventListener('keydown', onKey);
    document.body.style.overflow = 'hidden';
    return () => {
      window.removeEventListener('keydown', onKey);
      document.body.style.overflow = '';
    };
  }, [open]);

  return (
    <>
      <div ref={sentinel} className="absolute top-0 h-px w-full" aria-hidden="true" />
      <header
        className={`fixed inset-x-0 top-0 z-40 border-b transition-colors duration-300 ${
          scrolled || open
            ? 'border-white/[0.08] bg-[#07090E]/90 md:backdrop-blur-xl'
            : 'border-transparent bg-transparent'
        }`}
      >
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-5 sm:px-8 lg:px-12">
          <a
            href="#hero"
            className="inline-flex min-h-[44px] items-center font-display text-xl font-bold tracking-tight text-white sm:text-2xl"
            aria-label="Mahid Malik, back to top"
            onClick={() => setOpen(false)}
          >
            Mahid<span className="text-blue-400">.</span>Malik
          </a>

          <nav className="hidden items-center gap-1 md:flex" aria-label="Main">
            {LINKS.map((l) => (
              <a
                key={l.id}
                href={`#${l.id}`}
                aria-current={active === l.id ? 'true' : undefined}
                className={`relative rounded-lg px-3.5 py-3 text-sm font-medium transition-colors duration-200 ${
                  active === l.id ? 'text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                {l.label}
                <span
                  className={`absolute inset-x-3.5 -bottom-px h-px origin-left bg-blue-400 transition-transform duration-300 ${
                    active === l.id ? 'scale-x-100' : 'scale-x-0'
                  }`}
                />
              </a>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            <a
              href="#contact"
              className="group hidden h-11 items-center gap-1.5 rounded-xl bg-blue-600 px-5 text-sm font-semibold text-white transition duration-200 hover:-translate-y-0.5 hover:bg-blue-500 active:translate-y-0 active:scale-[0.98] sm:inline-flex"
            >
              Let&apos;s Talk
              <ArrowUpRight className="h-3.5 w-3.5 transition-transform duration-200 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
            </a>
            <button
              type="button"
              className="inline-flex h-11 w-11 items-center justify-center rounded-xl border border-white/[0.1] text-white md:hidden"
              aria-label={open ? 'Close menu' : 'Open menu'}
              aria-expanded={open}
              aria-controls="mobile-menu"
              onClick={() => setOpen((v) => !v)}
            >
              {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </div>

        {/* Mobile menu: opacity/transform only, always mounted so there is no layout jump */}
        <div
          id="mobile-menu"
          className={`absolute inset-x-0 top-16 h-[calc(100dvh-4rem)] bg-[#07090E] px-4 pt-4 transition duration-300 md:hidden ${
            open ? 'visible translate-y-0 opacity-100' : 'invisible -translate-y-2 opacity-0'
          }`}
        >
          <nav className="flex flex-col" aria-label="Mobile">
            {LINKS.map((l, i) => (
              <a
                key={l.id}
                href={`#${l.id}`}
                onClick={() => setOpen(false)}
                className="flex items-center justify-between border-b border-white/[0.06] py-5 font-display text-2xl font-bold text-white"
              >
                <span>{l.label}</span>
                <span className="font-mono text-xs text-slate-500">0{i + 1}</span>
              </a>
            ))}
          </nav>
          <a
            href="#contact"
            onClick={() => setOpen(false)}
            className="mt-8 flex h-12 items-center justify-center rounded-xl bg-blue-600 font-semibold text-white"
          >
            Let&apos;s Talk
          </a>
        </div>
      </header>
    </>
  );
};
