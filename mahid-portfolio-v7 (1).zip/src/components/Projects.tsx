import React from 'react';
import { ArrowUpRight } from 'lucide-react';
import { PROJECTS } from '../data/portfolioData';
import { Project } from '../types';
import { PhoneCall } from 'lucide-react';
import { SectionHeading } from './SectionHeading';
import { RecordedDemo } from './RecordedDemo';

// Asymmetric 12-col rhythm on large screens: 7/5 then 5/7.
const SPAN = ['lg:col-span-7', 'lg:col-span-5', 'lg:col-span-5', 'lg:col-span-7'];

// Static, calm visual for the voice project: no fake call UI, no waveform.
const VoiceVisual: React.FC = () => (
  <div className="flex h-full w-full items-center justify-center bg-[radial-gradient(60%_80%_at_50%_50%,rgba(37,99,235,0.18),transparent)]" aria-hidden="true">
    <div className="relative flex h-32 w-32 items-center justify-center">
      <span className="absolute inset-0 rounded-full border border-blue-400/15" />
      <span className="absolute inset-4 rounded-full border border-blue-400/25" />
      <span className="flex h-16 w-16 items-center justify-center rounded-2xl border border-blue-400/40 bg-[#0B1224] transition-transform duration-500 group-hover:scale-110">
        <PhoneCall className="h-7 w-7 text-cyan-300" strokeWidth={1.5} />
      </span>
    </div>
  </div>
);

const Body: React.FC<{ p: Project; footer: React.ReactNode }> = ({ p, footer }) => (
  <>
    <div className="relative h-56 overflow-hidden bg-slate-900 sm:h-64 lg:h-72">
      {p.image ? (
        <img
          src={p.image}
          alt={`${p.title} preview`}
          width={1000}
          height={625}
          loading="lazy"
          decoding="async"
          className="h-full w-full object-cover object-top transition-transform duration-700 ease-out group-hover:scale-[1.04]"
        />
      ) : (
        <VoiceVisual />
      )}
      <div className="absolute inset-0 bg-gradient-to-t from-[#0B0F19] via-transparent to-transparent opacity-70" />
    </div>
    <div className="flex flex-1 flex-col p-7 sm:p-9">
      <p className="font-mono text-[11px] uppercase tracking-wider text-blue-400">{p.category}</p>
      <h3 className="mt-2 font-display text-xl font-bold text-white transition-transform duration-300 group-hover:translate-x-0.5 sm:text-2xl">{p.title}</h3>
      <p className="mt-2 text-[15px] leading-relaxed text-slate-400">{p.description}</p>
      <ul className="mt-5 flex flex-wrap gap-1.5">
        {p.tools.map((t) => (
          <li key={t} className="rounded-md border border-white/[0.08] px-2 py-0.5 font-mono text-[10px] text-slate-300">{t}</li>
        ))}
      </ul>
      <div className="mt-auto pt-6">{footer}</div>
    </div>
  </>
);

const cardBase = 'group flex h-full flex-col overflow-hidden rounded-3xl border border-white/[0.08] bg-[#0B0F19] transition duration-300';

const Card: React.FC<{ p: Project; className: string; index: number }> = ({ p, className, index }) => {
  const style = { transitionDelay: `${(index % 2) * 100}ms` };

  if (p.audioDemo) {
    return (
      <li className={`reveal-on-scroll ${className}`} style={style}>
        <article className={`${cardBase} hover:border-white/[0.18]`}>
          <Body p={p} footer={<RecordedDemo />} />
        </article>
      </li>
    );
  }

  if (p.url) {
    return (
      <li className={`reveal-on-scroll ${className}`} style={style}>
        <a
          href={p.url}
          target="_blank"
          rel="noopener noreferrer"
          aria-label={`${p.title} (opens in a new tab)`}
          className={`${cardBase} hover:-translate-y-1 hover:border-blue-400/40`}
        >
          <Body
            p={p}
            footer={
              <span className="inline-flex items-center gap-1.5 text-sm font-semibold text-cyan-300">
                View live demo
                <ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5" aria-hidden="true" />
              </span>
            }
          />
        </a>
      </li>
    );
  }

  return (
    <li className={`reveal-on-scroll ${className}`} style={style}>
      <article className={cardBase}>
        <Body p={p} footer={<span className="font-mono text-xs text-slate-500">Demo coming soon</span>} />
      </article>
    </li>
  );
};

export const Projects: React.FC = () => (
  <section id="work" aria-labelledby="work-title" className="scroll-mt-16 border-t border-white/[0.06] py-28 lg:py-40">
    <div className="mx-auto max-w-7xl px-5 sm:px-8 lg:px-12">
      <SectionHeading id="work-title" eyebrow="Portfolio" title="Selected Work" subtitle="Real systems, experiments and digital products." />
      <ul className="mt-16 grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-12 lg:gap-10">
        {PROJECTS.map((p, i) => (
          <Card key={p.id} p={p} index={i} className={SPAN[i % SPAN.length]} />
        ))}
      </ul>
    </div>
  </section>
);
