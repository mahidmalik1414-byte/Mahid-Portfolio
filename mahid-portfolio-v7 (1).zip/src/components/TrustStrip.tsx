import React from 'react';
import { TRUST } from '../data/portfolioData';

export const TrustStrip: React.FC = () => (
  <section aria-label="How I work" className="border-y border-white/[0.06]">
    <ul className="mx-auto grid max-w-7xl grid-cols-2 lg:grid-cols-4">
      {TRUST.map((t, i) => (
        <li
          key={t.title}
          className={`reveal-on-scroll px-5 py-9 sm:px-8 lg:px-12 ${i % 2 === 1 ? 'border-l border-white/[0.06]' : ''} ${
            i > 0 ? 'lg:border-l lg:border-white/[0.06]' : ''
          } ${i > 1 ? 'border-t border-white/[0.06] lg:border-t-0' : ''}`}
        >
          <p className="font-display text-lg font-bold text-white">{t.title}</p>
          <p className="mt-1 text-sm text-slate-400">{t.description}</p>
        </li>
      ))}
    </ul>
  </section>
);
