import { lazy, Suspense } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { TrustStrip } from './components/TrustStrip';
import { Services } from './components/Services';
import { Projects } from './components/Projects';
import { Tools } from './components/Tools';
import { Process } from './components/Process';
import { About } from './components/About';
import { Contact } from './components/Contact';
import { Footer } from './components/Footer';
import { useScrollReveal } from './hooks/useScrollReveal';

// Non-critical: loaded after first paint.
const ChatbotWidget = lazy(() => import('./components/ChatbotWidget').then((m) => ({ default: m.ChatbotWidget })));

export default function App() {
  useScrollReveal();

  // Chatbot links may name older section ids; map them onto the current page.
  const goTo = (id: string) => {
    const target = id.startsWith('service-') ? 'services' : id === 'why' || id === 'testimonials' ? 'about' : id;
    document.getElementById(target)?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="relative min-h-screen overflow-x-hidden bg-[#07090E] text-slate-100 selection:bg-blue-600 selection:text-white">
      <a
        href="#main"
        className="sr-only z-50 rounded-lg bg-white px-4 py-2 text-sm font-semibold text-black focus:not-sr-only focus:fixed focus:left-4 focus:top-4"
      >
        Skip to content
      </a>
      <Navbar />
      <main id="main">
        <Hero />
        <TrustStrip />
        <Services />
        <Projects />
        <Tools />
        <Process />
        <About />
        <Contact />
      </main>
      <Footer />
      <Suspense fallback={null}>
        <ChatbotWidget onNavigate={goTo} />
      </Suspense>
    </div>
  );
}
